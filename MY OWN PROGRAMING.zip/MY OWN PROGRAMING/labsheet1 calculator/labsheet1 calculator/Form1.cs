﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labsheet1_calculator
{
    public partial class Form1 : Form
    {
        int a, b;
        public Form1()
        {
            InitializeComponent();
            
       
        }
       
       
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        { double a,b;
            a = double.Parse(txtnum1.Text);
            b = double.Parse(txtnum2.Text);
            txtresult.Text = (a / b).ToString();
     
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtnum1.Text = "";
            txtnum2.Text = "";
            txtresult.Text = "";
        }

        private void lblresult_Click(object sender, EventArgs e)
        {

        }

        private void btnmulti_Click(object sender, EventArgs e)
        {
            a = Int32.Parse(txtnum1.Text);
            b = Int32.Parse(txtnum2.Text);
            txtresult.Text = (a * b).ToString();
     
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            a = Int32.Parse(txtnum1.Text);
            b = Int32.Parse(txtnum2.Text);
            txtresult.Text = (a - b).ToString();
     
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            a = Int32.Parse(txtnum1.Text);
            b = Int32.Parse(txtnum2.Text);
            txtresult.Text = (a + b).ToString();
     
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
