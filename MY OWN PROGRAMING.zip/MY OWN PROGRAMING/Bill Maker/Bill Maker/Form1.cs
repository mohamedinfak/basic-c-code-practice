﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bill_Maker
{
    public partial class frmBillMaker : Form
    {
        public frmBillMaker()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            int y;
            double x;
            
            x = Double.Parse(txtUnitPrice.Text);
            y = Int32.Parse(txtQuantity.Text);
            lbltotalOutput.Text = (x * y).ToString();
            rtbBill.Text = "Item Name" + "\t" + "\t" + "Unit PriceQty" + "\t" + "\t" + "Sub Total"+"\n"+"\n";
            rtbBill.Text += txtItemNum.Text + "\t" + "\t"+ "\t"+ txtUnitPrice.Text + " X " +txtQuantity.Text+ " =" + "\t" + "\t" + "\t" + "Rs. " + lbltotalOutput.Text + "\n";

        }
    }
}
