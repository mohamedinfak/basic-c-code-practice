﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elactricity_Bill_program
{
    class Program
    {
        static void Main(string[] args)
        {
            int units;
            Double unitprice, totalamount;
            Console.WriteLine("Enter Number of units:");
            units = Convert.ToInt32(Console.ReadLine());
            if (units <= 30)
                unitprice = 30;
            else if (units <= 60)
                unitprice = 7;
            else if (units <= 120)
                unitprice = 10;
            else
                unitprice = 20;
            totalamount = units * unitprice;
            Console.WriteLine("total amount" + totalamount);

        }
    }
}
