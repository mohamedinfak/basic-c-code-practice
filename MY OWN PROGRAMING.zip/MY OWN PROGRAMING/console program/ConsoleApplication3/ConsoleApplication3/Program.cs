﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            Double no1, no2;
            Double answer;
            char op;
            Console.Write("type a number ,and hen press enter:");
            no1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("enter the second number:");
            no2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("A_ addition");
            Console.WriteLine("S_subraction");
            Console.WriteLine("M_multiplication");
            Console.WriteLine("d_divition");
            Console.WriteLine("enter your option:");
            op = Convert.ToChar(Console.ReadLine());
            switch (op)
            {
                case 'a':
                    answer = no1 + no2;
                    break;
                case 's':
                    answer = no1 - no2;
                    break;
                case 'm':
                    answer = no1 * no2;
                    break;
                case 'd':
                    answer = no1 / no2;
                    break;
                default:
                    answer = (-99.99);
                    break;

            }
            {
                 if  (answer ==(-99.99))
                     Console.WriteLine("wrong option!!!");
                else Console.WriteLine("answer is " + answer);

            }
        }
    }
}
