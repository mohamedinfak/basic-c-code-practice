﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
           Char gender;
            int age;
            Console.Write("enter your age:");
            age = Convert.ToInt32(Console.ReadLine());
            Console.Write("enter the gender:");
            gender = Convert.ToChar(Console.ReadLine());
           // gender= Console.ReadLine();
            if((gender == 'M'&& age>=22)) //(gender =='F' && age >= 18))
                Console.WriteLine("You are major!!!");
            else Console.WriteLine("You are minor!!!");

        }
    }
}
