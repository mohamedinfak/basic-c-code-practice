﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Electricity_Bill_program2
{
    class Program
    {
        static void Main(string[] args)
        {
            int units;
            Double totalamount;
            Console.WriteLine("Enter number of units:");
            units = Convert.ToInt32(Console.ReadLine());
            if (units <= 30)
                totalamount = units * 5;
            else if (units <= 60)
                totalamount = 30 * 5 + (units - 30) * 7;
            else if (units <= 120)
                totalamount = 30 * 5 + 30 * 7 + (units - 60) * 10;
            else
                totalamount = 30 * 5 + 30 * 7 + 60 * 10 + (units - 120) * 20;
            Console.WriteLine("the total amount" + totalamount);




        }
    }
}
