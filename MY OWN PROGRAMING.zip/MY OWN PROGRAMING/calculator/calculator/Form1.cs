﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class frmCalculator : Form
    {
        public frmCalculator()
        {
            InitializeComponent();

        }
        double num1, num2, result;

        private void btnSub_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtNum1.Text);
            num2 = Double.Parse(txtNum2.Text);
            txtResult.Text = (num1 - num2).ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtNum1.Text);
            num2 = Double.Parse(txtNum2.Text);
            txtResult.Text = (num1 + num2).ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResult.Text= "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtNum1.Text);
            num2 = Double.Parse(txtNum2.Text);
            txtResult.Text = (num1 * num2).ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            num1 = Double.Parse(txtNum1.Text);
            num2 = Double.Parse(txtNum2.Text);
            txtResult.Text = (num1 / num2).ToString();
        }
    }
}
