﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration_foem
{
    public partial class frmRegistrationForm : Form
    {
        public frmRegistrationForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            rtboutput.Text = "Name: " + txtFName.Text + " " + txtLName.Text + "\n" + "\n";
            if (rdoMale.Checked)
                rtboutput.Text += "Gender: Male"+"\n";
            else if(rdoFemale.Checked)
                rtboutput.Text += "Gender: Female" + "\n";
            rtboutput.Text += "Selected Course: " + comboCourse.Text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFName.Text = "";
            txtLName.Text = "";
            rdoFemale.Checked = false;
            rdoMale.Checked = false;
            comboCourse.Text = "";
            rtboutput.Text = "";
        }
    }
}
